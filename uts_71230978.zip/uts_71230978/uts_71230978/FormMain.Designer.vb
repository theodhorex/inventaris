﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        PanelTop = New Panel()
        LabelTitle1 = New Label()
        LabelTitle2 = New Label()
        PanelLawan = New Panel()
        LabelLawanJudul = New Label()
        PictureBoxLawan = New PictureBox()
        LabelLawanNama = New Label()
        FlowLayoutPanelItems = New FlowLayoutPanel()
        PictureBox1 = New PictureBox()
        PictureBox2 = New PictureBox()
        PanelTop.SuspendLayout()
        PanelLawan.SuspendLayout()
        CType(PictureBoxLawan, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PanelTop
        ' 
        PanelTop.BackColor = Color.White
        PanelTop.Controls.Add(PictureBox2)
        PanelTop.Controls.Add(PictureBox1)
        PanelTop.Controls.Add(LabelTitle1)
        PanelTop.Controls.Add(LabelTitle2)
        PanelTop.Dock = DockStyle.Top
        PanelTop.Location = New Point(0, 0)
        PanelTop.Name = "PanelTop"
        PanelTop.Size = New Size(400, 80)
        PanelTop.TabIndex = 2
        ' 
        ' LabelTitle1
        ' 
        LabelTitle1.AutoSize = True
        LabelTitle1.Font = New Font("Segoe UI", 18.0F, FontStyle.Bold)
        LabelTitle1.Location = New Point(128, 15)
        LabelTitle1.Name = "LabelTitle1"
        LabelTitle1.Size = New Size(109, 32)
        LabelTitle1.TabIndex = 1
        LabelTitle1.Text = "Dinamix"
        ' 
        ' LabelTitle2
        ' 
        LabelTitle2.AutoSize = True
        LabelTitle2.Font = New Font("Segoe UI", 11.0F)
        LabelTitle2.Location = New Point(128, 51)
        LabelTitle2.Name = "LabelTitle2"
        LabelTitle2.Size = New Size(137, 20)
        LabelTitle2.TabIndex = 2
        LabelTitle2.Text = "Rock Paper Scissors"
        ' 
        ' PanelLawan
        ' 
        PanelLawan.BackColor = Color.WhiteSmoke
        PanelLawan.Controls.Add(LabelLawanJudul)
        PanelLawan.Controls.Add(PictureBoxLawan)
        PanelLawan.Controls.Add(LabelLawanNama)
        PanelLawan.Dock = DockStyle.Top
        PanelLawan.Location = New Point(0, 80)
        PanelLawan.Name = "PanelLawan"
        PanelLawan.Padding = New Padding(10)
        PanelLawan.Size = New Size(400, 160)
        PanelLawan.TabIndex = 1
        ' 
        ' LabelLawanJudul
        ' 
        LabelLawanJudul.AutoSize = True
        LabelLawanJudul.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        LabelLawanJudul.Location = New Point(12, 10)
        LabelLawanJudul.Name = "LabelLawanJudul"
        LabelLawanJudul.Size = New Size(55, 19)
        LabelLawanJudul.TabIndex = 0
        LabelLawanJudul.Text = "Lawan:"
        ' 
        ' PictureBoxLawan
        ' 
        PictureBoxLawan.BackColor = Color.White
        PictureBoxLawan.BorderStyle = BorderStyle.FixedSingle
        PictureBoxLawan.Location = New Point(70, 33)
        PictureBoxLawan.Name = "PictureBoxLawan"
        PictureBoxLawan.Size = New Size(100, 100)
        PictureBoxLawan.SizeMode = PictureBoxSizeMode.Zoom
        PictureBoxLawan.TabIndex = 1
        PictureBoxLawan.TabStop = False
        ' 
        ' LabelLawanNama
        ' 
        LabelLawanNama.AutoSize = True
        LabelLawanNama.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        LabelLawanNama.Location = New Point(222, 50)
        LabelLawanNama.Name = "LabelLawanNama"
        LabelLawanNama.Size = New Size(15, 19)
        LabelLawanNama.TabIndex = 2
        LabelLawanNama.Text = "?"
        ' 
        ' FlowLayoutPanelItems
        ' 
        FlowLayoutPanelItems.AutoScroll = True
        FlowLayoutPanelItems.BackColor = Color.WhiteSmoke
        FlowLayoutPanelItems.Dock = DockStyle.Fill
        FlowLayoutPanelItems.Location = New Point(0, 240)
        FlowLayoutPanelItems.Name = "FlowLayoutPanelItems"
        FlowLayoutPanelItems.Padding = New Padding(10)
        FlowLayoutPanelItems.Size = New Size(400, 310)
        FlowLayoutPanelItems.TabIndex = 0
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.List
        PictureBox1.Location = New Point(3, 15)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(70, 50)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 3
        PictureBox1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = My.Resources.Resources.retrybutton
        PictureBox2.Location = New Point(306, 15)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(70, 50)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 4
        PictureBox2.TabStop = False
        ' 
        ' FormMain
        ' 
        ClientSize = New Size(400, 550)
        Controls.Add(FlowLayoutPanelItems)
        Controls.Add(PanelLawan)
        Controls.Add(PanelTop)
        Name = "FormMain"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Dinamix Rock Paper Scissors"
        PanelTop.ResumeLayout(False)
        PanelTop.PerformLayout()
        PanelLawan.ResumeLayout(False)
        PanelLawan.PerformLayout()
        CType(PictureBoxLawan, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents PanelTop As System.Windows.Forms.Panel
    Friend WithEvents LabelTitle1 As System.Windows.Forms.Label
    Friend WithEvents LabelTitle2 As System.Windows.Forms.Label
    Friend WithEvents PanelLawan As System.Windows.Forms.Panel
    Friend WithEvents LabelLawanJudul As System.Windows.Forms.Label
    Friend WithEvents PictureBoxLawan As System.Windows.Forms.PictureBox
    Friend WithEvents LabelLawanNama As System.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanelItems As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox

End Class