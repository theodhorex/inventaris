﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormAddRule
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        PanelTop = New Panel()
        LblTitle1 = New Label()
        LblTitle2 = New Label()
        LblWinner = New Label()
        CmbWinner = New ComboBox()
        TxtNamaWinner = New TextBox()
        BtnBrowseWinner = New Button()
        PbWinner = New PictureBox()
        LblLoser = New Label()
        CmbLoser = New ComboBox()
        TxtNamaLoser = New TextBox()
        BtnBrowseLoser = New Button()
        PbLoser = New PictureBox()
        PanelBottom = New Panel()
        BtnSimpan = New Button()
        BtnBatal = New Button()
        PanelTop.SuspendLayout()
        CType(PbWinner, ComponentModel.ISupportInitialize).BeginInit()
        CType(PbLoser, ComponentModel.ISupportInitialize).BeginInit()
        PanelBottom.SuspendLayout()
        SuspendLayout()
        ' 
        ' PanelTop
        ' 
        PanelTop.BackColor = Color.White
        PanelTop.Controls.Add(LblTitle1)
        PanelTop.Controls.Add(LblTitle2)
        PanelTop.Dock = DockStyle.Top
        PanelTop.Location = New Point(0, 0)
        PanelTop.Name = "PanelTop"
        PanelTop.Size = New Size(400, 75)
        PanelTop.TabIndex = 12
        ' 
        ' LblTitle1
        ' 
        LblTitle1.AutoSize = True
        LblTitle1.Font = New Font("Segoe UI", 16.0F, FontStyle.Bold)
        LblTitle1.Location = New Point(52, 12)
        LblTitle1.Name = "LblTitle1"
        LblTitle1.Size = New Size(146, 30)
        LblTitle1.TabIndex = 0
        LblTitle1.Text = "Tambah Rule"
        ' 
        ' LblTitle2
        ' 
        LblTitle2.AutoSize = True
        LblTitle2.Font = New Font("Segoe UI", 10.0F)
        LblTitle2.Location = New Point(70, 42)
        LblTitle2.Name = "LblTitle2"
        LblTitle2.Size = New Size(128, 19)
        LblTitle2.TabIndex = 1
        LblTitle2.Text = "Rock Paper Scissors"
        ' 
        ' LblWinner
        ' 
        LblWinner.AutoSize = True
        LblWinner.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold)
        LblWinner.Location = New Point(24, 85)
        LblWinner.Name = "LblWinner"
        LblWinner.Size = New Size(124, 15)
        LblWinner.TabIndex = 0
        LblWinner.Text = "Item yang lebih kuat:"
        ' 
        ' CmbWinner
        ' 
        CmbWinner.DropDownStyle = ComboBoxStyle.DropDownList
        CmbWinner.Location = New Point(15, 108)
        CmbWinner.Name = "CmbWinner"
        CmbWinner.Size = New Size(200, 23)
        CmbWinner.TabIndex = 1
        ' 
        ' TxtNamaWinner
        ' 
        TxtNamaWinner.Location = New Point(12, 141)
        TxtNamaWinner.Name = "TxtNamaWinner"
        TxtNamaWinner.PlaceholderText = "Nama item baru..."
        TxtNamaWinner.Size = New Size(200, 23)
        TxtNamaWinner.TabIndex = 2
        TxtNamaWinner.Visible = False
        ' 
        ' BtnBrowseWinner
        ' 
        BtnBrowseWinner.FlatStyle = FlatStyle.Flat
        BtnBrowseWinner.Location = New Point(15, 170)
        BtnBrowseWinner.Name = "BtnBrowseWinner"
        BtnBrowseWinner.Size = New Size(120, 28)
        BtnBrowseWinner.TabIndex = 3
        BtnBrowseWinner.Text = "Browse Gambar"
        BtnBrowseWinner.Visible = False
        ' 
        ' PbWinner
        ' 
        PbWinner.BackColor = Color.White
        PbWinner.BorderStyle = BorderStyle.FixedSingle
        PbWinner.Location = New Point(263, 85)
        PbWinner.Name = "PbWinner"
        PbWinner.Size = New Size(100, 100)
        PbWinner.SizeMode = PictureBoxSizeMode.Zoom
        PbWinner.TabIndex = 4
        PbWinner.TabStop = False
        ' 
        ' LblLoser
        ' 
        LblLoser.AutoSize = True
        LblLoser.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold)
        LblLoser.Location = New Point(34, 265)
        LblLoser.Name = "LblLoser"
        LblLoser.Size = New Size(133, 15)
        LblLoser.TabIndex = 6
        LblLoser.Text = "Item yang lebih lemah:"
        ' 
        ' CmbLoser
        ' 
        CmbLoser.DropDownStyle = ComboBoxStyle.DropDownList
        CmbLoser.Location = New Point(15, 283)
        CmbLoser.Name = "CmbLoser"
        CmbLoser.Size = New Size(200, 23)
        CmbLoser.TabIndex = 7
        ' 
        ' TxtNamaLoser
        ' 
        TxtNamaLoser.Location = New Point(16, 312)
        TxtNamaLoser.Name = "TxtNamaLoser"
        TxtNamaLoser.PlaceholderText = "Nama item baru..."
        TxtNamaLoser.Size = New Size(200, 23)
        TxtNamaLoser.TabIndex = 8
        TxtNamaLoser.Visible = False
        ' 
        ' BtnBrowseLoser
        ' 
        BtnBrowseLoser.FlatStyle = FlatStyle.Flat
        BtnBrowseLoser.Location = New Point(16, 350)
        BtnBrowseLoser.Name = "BtnBrowseLoser"
        BtnBrowseLoser.Size = New Size(120, 28)
        BtnBrowseLoser.TabIndex = 9
        BtnBrowseLoser.Text = "Browse Gambar"
        BtnBrowseLoser.Visible = False
        ' 
        ' PbLoser
        ' 
        PbLoser.BackColor = Color.White
        PbLoser.BorderStyle = BorderStyle.FixedSingle
        PbLoser.Location = New Point(237, 251)
        PbLoser.Name = "PbLoser"
        PbLoser.Size = New Size(100, 100)
        PbLoser.SizeMode = PictureBoxSizeMode.Zoom
        PbLoser.TabIndex = 10
        PbLoser.TabStop = False
        ' 
        ' PanelBottom
        ' 
        PanelBottom.BackColor = Color.White
        PanelBottom.Controls.Add(BtnSimpan)
        PanelBottom.Controls.Add(BtnBatal)
        PanelBottom.Dock = DockStyle.Bottom
        PanelBottom.Location = New Point(0, 445)
        PanelBottom.Name = "PanelBottom"
        PanelBottom.Size = New Size(400, 55)
        PanelBottom.TabIndex = 11
        ' 
        ' BtnSimpan
        ' 
        BtnSimpan.Location = New Point(263, 20)
        BtnSimpan.Name = "BtnSimpan"
        BtnSimpan.Size = New Size(87, 23)
        BtnSimpan.TabIndex = 14
        BtnSimpan.Text = "Simpan Rule"
        BtnSimpan.UseVisualStyleBackColor = True
        ' 
        ' BtnBatal
        ' 
        BtnBatal.Location = New Point(34, 18)
        BtnBatal.Name = "BtnBatal"
        BtnBatal.Size = New Size(75, 23)
        BtnBatal.TabIndex = 13
        BtnBatal.Text = "Batal"
        BtnBatal.UseVisualStyleBackColor = True
        ' 
        ' FormAddRule
        ' 
        ClientSize = New Size(400, 500)
        Controls.Add(LblWinner)
        Controls.Add(CmbWinner)
        Controls.Add(TxtNamaWinner)
        Controls.Add(BtnBrowseWinner)
        Controls.Add(PbWinner)
        Controls.Add(LblLoser)
        Controls.Add(CmbLoser)
        Controls.Add(TxtNamaLoser)
        Controls.Add(BtnBrowseLoser)
        Controls.Add(PbLoser)
        Controls.Add(PanelBottom)
        Controls.Add(PanelTop)
        Name = "FormAddRule"
        StartPosition = FormStartPosition.CenterParent
        Text = "Tambah Rule"
        PanelTop.ResumeLayout(False)
        PanelTop.PerformLayout()
        CType(PbWinner, ComponentModel.ISupportInitialize).EndInit()
        CType(PbLoser, ComponentModel.ISupportInitialize).EndInit()
        PanelBottom.ResumeLayout(False)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PanelTop As System.Windows.Forms.Panel
    Friend WithEvents LblTitle1 As System.Windows.Forms.Label
    Friend WithEvents LblTitle2 As System.Windows.Forms.Label
    Friend WithEvents LblWinner As System.Windows.Forms.Label
    Friend WithEvents CmbWinner As System.Windows.Forms.ComboBox
    Friend WithEvents TxtNamaWinner As System.Windows.Forms.TextBox
    Friend WithEvents BtnBrowseWinner As System.Windows.Forms.Button
    Friend WithEvents PbWinner As System.Windows.Forms.PictureBox
    Friend WithEvents LblLoser As System.Windows.Forms.Label
    Friend WithEvents CmbLoser As System.Windows.Forms.ComboBox
    Friend WithEvents TxtNamaLoser As System.Windows.Forms.TextBox
    Friend WithEvents BtnBrowseLoser As System.Windows.Forms.Button
    Friend WithEvents PbLoser As System.Windows.Forms.PictureBox
    Friend WithEvents PanelBottom As System.Windows.Forms.Panel
    Friend WithEvents BtnSimpan As Button
    Friend WithEvents BtnBatal As Button

End Class