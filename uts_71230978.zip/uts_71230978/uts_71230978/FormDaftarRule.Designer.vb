﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormDaftarRule
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        PanelTop = New Panel()
        LabelTitle1 = New Label()
        LabelTitle2 = New Label()
        LvwRule = New ListView()
        BtnTambah = New PictureBox()
        PanelBottom = New Panel()
        BtnKembali = New PictureBox()
        PanelTop.SuspendLayout()
        CType(BtnTambah, ComponentModel.ISupportInitialize).BeginInit()
        PanelBottom.SuspendLayout()
        CType(BtnKembali, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PanelTop
        ' 
        PanelTop.BackColor = Color.White
        PanelTop.Controls.Add(LabelTitle1)
        PanelTop.Controls.Add(LabelTitle2)
        PanelTop.Dock = DockStyle.Top
        PanelTop.Location = New Point(0, 0)
        PanelTop.Name = "PanelTop"
        PanelTop.Size = New Size(400, 80)
        PanelTop.TabIndex = 2
        ' 
        ' LabelTitle1
        ' 
        LabelTitle1.AutoSize = True
        LabelTitle1.Font = New Font("Segoe UI", 16.0F, FontStyle.Bold)
        LabelTitle1.Location = New Point(80, 10)
        LabelTitle1.Name = "LabelTitle1"
        LabelTitle1.Size = New Size(130, 30)
        LabelTitle1.TabIndex = 0
        LabelTitle1.Text = "Daftar Rule"
        ' 
        ' LabelTitle2
        ' 
        LabelTitle2.AutoSize = True
        LabelTitle2.Font = New Font("Segoe UI", 10.0F)
        LabelTitle2.Location = New Point(80, 45)
        LabelTitle2.Name = "LabelTitle2"
        LabelTitle2.Size = New Size(128, 19)
        LabelTitle2.TabIndex = 1
        LabelTitle2.Text = "Rock Paper Scissors"
        ' 
        ' LvwRule
        ' 
        LvwRule.Dock = DockStyle.Fill
        LvwRule.Location = New Point(0, 80)
        LvwRule.Name = "LvwRule"
        LvwRule.Size = New Size(400, 365)
        LvwRule.TabIndex = 0
        LvwRule.UseCompatibleStateImageBehavior = False
        ' 
        ' BtnTambah
        ' 
        BtnTambah.Image = My.Resources.Resources.add
        BtnTambah.Location = New Point(343, 7)
        BtnTambah.Name = "BtnTambah"
        BtnTambah.Size = New Size(45, 41)
        BtnTambah.SizeMode = PictureBoxSizeMode.StretchImage
        BtnTambah.TabIndex = 4
        BtnTambah.TabStop = False
        ' 
        ' PanelBottom
        ' 
        PanelBottom.BackColor = Color.White
        PanelBottom.Controls.Add(BtnKembali)
        PanelBottom.Controls.Add(BtnTambah)
        PanelBottom.Dock = DockStyle.Bottom
        PanelBottom.Location = New Point(0, 445)
        PanelBottom.Name = "PanelBottom"
        PanelBottom.Size = New Size(400, 55)
        PanelBottom.TabIndex = 1
        ' 
        ' BtnKembali
        ' 
        BtnKembali.Image = My.Resources.Resources.buttonback
        BtnKembali.Location = New Point(12, 7)
        BtnKembali.Name = "BtnKembali"
        BtnKembali.Size = New Size(45, 41)
        BtnKembali.SizeMode = PictureBoxSizeMode.StretchImage
        BtnKembali.TabIndex = 5
        BtnKembali.TabStop = False
        ' 
        ' FormDaftarRule
        ' 
        ClientSize = New Size(400, 500)
        Controls.Add(LvwRule)
        Controls.Add(PanelBottom)
        Controls.Add(PanelTop)
        Name = "FormDaftarRule"
        StartPosition = FormStartPosition.CenterParent
        Text = "Daftar Rule - ListView"
        PanelTop.ResumeLayout(False)
        PanelTop.PerformLayout()
        CType(BtnTambah, ComponentModel.ISupportInitialize).EndInit()
        PanelBottom.ResumeLayout(False)
        CType(BtnKembali, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents PanelTop As System.Windows.Forms.Panel
    Friend WithEvents LabelTitle1 As System.Windows.Forms.Label
    Friend WithEvents LabelTitle2 As System.Windows.Forms.Label
    Friend WithEvents LvwRule As System.Windows.Forms.ListView
    Friend WithEvents BtnTambah As PictureBox
    Friend WithEvents PanelBottom As Panel
    Friend WithEvents BtnKembali As PictureBox

End Class