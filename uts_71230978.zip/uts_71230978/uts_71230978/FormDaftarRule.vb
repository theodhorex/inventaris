﻿Imports System.IO

Public Class FormDaftarRule

    Private itemFile As String = Path.Combine(Application.StartupPath, "items.txt")
    Private ruleFile As String = Path.Combine(Application.StartupPath, "rules.txt")
    Private imagesFolder As String = Path.Combine(Application.StartupPath, "images")

    Private Class ItemData
        Public Property Id As Integer
        Public Property Nama As String
        Public Property ImageFile As String
    End Class

    Private Class RuleData
        Public Property WinnerId As Integer
        Public Property LoserId As Integer
    End Class

    Private listItem As New List(Of ItemData)
    Private listRule As New List(Of RuleData)

    ' ImageList untuk ListView
    Private imgList As New ImageList()

    Private Sub FormDaftarRule_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        imgList.ImageSize = New Size(36, 36)
        imgList.ColorDepth = ColorDepth.Depth32Bit

        LoadItems()
        LoadRules()
        SetupListView()
        RenderRules()
    End Sub

    Private Sub LoadItems()
        listItem.Clear()
        If Not File.Exists(itemFile) Then Exit Sub
        For Each line In File.ReadAllLines(itemFile)
            Dim parts = line.Split(","c)
            If parts.Length >= 3 Then
                Dim item As New ItemData()
                item.Id = CInt(parts(0).Trim())
                item.Nama = parts(1).Trim()
                item.ImageFile = parts(2).Trim()
                listItem.Add(item)
            End If
        Next
    End Sub

    Private Sub LoadRules()
        listRule.Clear()
        If Not File.Exists(ruleFile) Then Exit Sub
        For Each line In File.ReadAllLines(ruleFile)
            If line.Trim().ToLower() = "else draw" Then Continue For
            Dim parts = line.Split(">"c)
            If parts.Length = 2 Then
                Dim r As New RuleData()
                r.WinnerId = CInt(parts(0).Trim())
                r.LoserId = CInt(parts(1).Trim())
                listRule.Add(r)
            End If
        Next
    End Sub

    Private Sub SetupListView()
        ' Siapkan ImageList dari semua item
        imgList.Images.Clear()
        For Each item In listItem
            Dim imgPath = Path.Combine(imagesFolder, item.ImageFile)
            If File.Exists(imgPath) Then
                Try
                    Using fs As New FileStream(imgPath, FileMode.Open, FileAccess.Read, FileShare.Read)
                        Using temp = Image.FromStream(fs)
                            imgList.Images.Add(item.Id.ToString(), New Bitmap(temp))
                        End Using
                    End Using
                Catch
                End Try
            End If
        Next

        LvwRule.SmallImageList = imgList
        LvwRule.LargeImageList = imgList
        LvwRule.View = View.Details
        LvwRule.FullRowSelect = True
        LvwRule.GridLines = True
        LvwRule.Columns.Clear()
        LvwRule.Columns.Add("Winner", 160)
        LvwRule.Columns.Add(">", 30)
        LvwRule.Columns.Add("Loser", 160)
        LvwRule.Columns.Add("", 50) ' kolom hapus
    End Sub

    Private Sub RenderRules()
        LvwRule.Items.Clear()
        For Each rule In listRule
            Dim winner = listItem.FirstOrDefault(Function(x) x.Id = rule.WinnerId)
            Dim loser = listItem.FirstOrDefault(Function(x) x.Id = rule.LoserId)
            If winner Is Nothing OrElse loser Is Nothing Then Continue For

            Dim lvi As New ListViewItem(winner.Nama)
            lvi.ImageKey = winner.Id.ToString()
            lvi.SubItems.Add(">")
            lvi.SubItems.Add(loser.Nama)
            lvi.SubItems.Add("🗑 Hapus")
            lvi.Tag = rule ' simpan rule asli di Tag
            LvwRule.Items.Add(lvi)
        Next
    End Sub

    ' Klik di ListView untuk hapus
    Private Sub LvwRule_MouseClick(sender As Object, e As MouseEventArgs) Handles LvwRule.MouseClick
        Dim hit = LvwRule.HitTest(e.X, e.Y)
        If hit.Item IsNot Nothing AndAlso hit.SubItem IsNot Nothing Then
            ' Kolom index 3 = tombol hapus
            Dim colIdx = hit.Item.SubItems.IndexOf(hit.SubItem)
            If colIdx = 3 Then
                Dim rule = DirectCast(hit.Item.Tag, RuleData)
                Dim konfirm = MessageBox.Show("Hapus rule ini?", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If konfirm = DialogResult.Yes Then
                    HapusRule(rule)
                End If
            End If
        End If
    End Sub

    Private Sub HapusRule(rule As RuleData)
        listRule.Remove(rule)
        SaveRules()
        RenderRules()
    End Sub

    Private Sub SaveRules()
        Dim lines As New List(Of String)
        For Each r In listRule
            lines.Add($"{r.WinnerId}>{r.LoserId}")
        Next
        lines.Add("else draw")
        File.WriteAllLines(ruleFile, lines)
    End Sub

    ' Tombol Tambah Rule (+)
    Private Sub BtnTambah_Click(sender As Object, e As EventArgs) Handles BtnTambah.Click
        Dim f As New FormAddRule
        f.ShowDialog()
        ' Reload setelah tambah
        LoadItems()
        LoadRules()
        SetupListView()
        RenderRules()
    End Sub

    ' Tombol Kembali
    Private Sub BtnKembali_Click(sender As Object, e As EventArgs) Handles BtnKembali.Click
        Close()
    End Sub

End Class