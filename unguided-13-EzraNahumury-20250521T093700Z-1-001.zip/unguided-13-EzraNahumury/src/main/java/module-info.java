module org.week12 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens org.week12 to javafx.fxml;
    exports org.week12;
    exports org.week12.data;
    opens org.week12.data to javafx.fxml;
}

