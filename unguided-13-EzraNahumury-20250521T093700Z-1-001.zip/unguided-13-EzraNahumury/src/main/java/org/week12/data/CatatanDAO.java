package org.week12.data;

import java.util.List;

public interface CatatanDAO {
    List<Catatan> getAllCatatan();
    boolean addCatatan(Catatan catatan);
    boolean updateCatatan(Catatan oldCatatan, Catatan newCatatan);
    boolean deleteCatatan(Catatan catatan);
}
