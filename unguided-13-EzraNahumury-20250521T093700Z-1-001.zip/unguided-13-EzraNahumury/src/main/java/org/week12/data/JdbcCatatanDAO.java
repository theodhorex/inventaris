package org.week12.data;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JdbcCatatanDAO implements CatatanDAO {
    private Connection connection;

    // Constructor for Dependency Injection
    public JdbcCatatanDAO(DatabaseDriver driver) {
        this.connection = driver.getConnection();
    }

    @Override
    public List<Catatan> getAllCatatan() {
        List<Catatan> catatans = new ArrayList<>();
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery("SELECT id, judul, konten, kategori FROM catatan");
            while (rs.next()) {
                Catatan catatan = new Catatan(
                        rs.getInt("id"),
                        rs.getString("judul"),
                        rs.getString("konten"),
                        rs.getString("kategori")
                );
                catatans.add(catatan);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return catatans;
    }


    @Override
    public boolean addCatatan(Catatan catatan) {
        try (PreparedStatement stmt = connection.prepareStatement("INSERT INTO catatan (judul, konten, kategori) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, catatan.getJudul());
            stmt.setString(2, catatan.getKonten());
            stmt.setString(3, catatan.getKategori());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        // Mendapatkan nilai id yang di-generate oleh database
                        int id = generatedKeys.getInt(1);
                        catatan.setId(id); // Atur id di objek Catatan
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


    @Override
    public boolean updateCatatan(Catatan oldCatatan, Catatan newCatatan) {
        try (PreparedStatement stmt = connection.prepareStatement("UPDATE catatan SET judul=?, konten=?, kategori=? WHERE id=?")) {
            stmt.setString(1, newCatatan.getJudul());
            stmt.setString(2, newCatatan.getKonten());
            stmt.setString(3, newCatatan.getKategori());
            stmt.setInt(4, oldCatatan.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean deleteCatatan(Catatan catatan) {
        try (PreparedStatement stmt = connection.prepareStatement("DELETE FROM catatan WHERE id=?")) {
            stmt.setInt(1, catatan.getId());
            return stmt.executeUpdate() >= 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
