package org.week12;

import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

public class AboutController implements Initializable {
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}