# UG13_A_2024
Modifikasi program daftar catatan sederhana ini agar menggunakan pola desain berikut:

## Kebutuhan Non-fungsional
- Refactor mekanisme akses database agar menggunakan pola desain Data Access Object. 
- Refactor mekanisme pemberian obyek Driver database dengan menggunakan pola desain Dependency Injection
  agar kedepannya aplikasi mudah berganti Drive database dengan yang lain