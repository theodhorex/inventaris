package com.example.minggu10;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class MahasiswaViewController implements Initializable {
    @FXML
    public TextField txtNim;
    @FXML
    public TextField txtNama;
    @FXML
    public TextField txtNilai;
    @FXML
    public TableView<Mahasiswa> table;
    @FXML
    public TableColumn<Mahasiswa, String> nim;
    @FXML
    public TableColumn<Mahasiswa, String> nama;
    @FXML
    public TableColumn<Mahasiswa, Float> nilai;

    private ObservableList<Mahasiswa> mahasiswaObservableList;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        mahasiswaObservableList = FXCollections.observableArrayList();
        table.setItems(mahasiswaObservableList);
        nim.setCellValueFactory(new PropertyValueFactory<>("Nim"));
        nama.setCellValueFactory(new PropertyValueFactory<>("Nama"));
        nilai.setCellValueFactory(new PropertyValueFactory<>("Nilai"));

        table.getSelectionModel().selectedItemProperty().addListener(
                new ChangeListener<Mahasiswa>() {
                    @Override
                    public void changed(ObservableValue<? extends Mahasiswa> observableValue, Mahasiswa mahasiswa, Mahasiswa t1) {
                        if (observableValue.getValue() != null) {
                            txtNim.setText(observableValue.getValue().getNim());
                            txtNama.setText(observableValue.getValue().getNama());
                            txtNilai.setText("" + observableValue.getValue().getNilai());
                        }
                    }
                });
    }

    public void onBtnAddClick(ActionEvent actionEvent) {
        if (isMahasiswaChanged()) {
            if(updateMahasiswa(table.getSelectionModel().getSelectedItem(),
                    new Mahasiswa(
                            txtNim.getText(),
                            txtNama.getText(),
                            Float.parseFloat(txtNilai.getText())))){
                Alert alert = new Alert(Alert.AlertType.INFORMATION,
                        "Data Updated");
                alert.show();
            }
        } else {
            addMahasiswa(new Mahasiswa(
                    txtNim.getText(),
                    txtNama.getText(),
                    Float.parseFloat(txtNilai.getText())));
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Data added");
            alert.show();
        }
        bersihkan();
    }

    private boolean updateMahasiswa(Mahasiswa oldMhs, Mahasiswa newMhs) {
        int indexOldMhs = mahasiswaObservableList.indexOf(oldMhs);
        mahasiswaObservableList.set(indexOldMhs, newMhs);
        return true;
    }

    private boolean isMahasiswaChanged() {
        Mahasiswa selectedMhs = table.getSelectionModel().getSelectedItem();
        if (selectedMhs == null)
            return false;

        return !selectedMhs.getNim().equalsIgnoreCase(txtNim.getText()) ||
                !selectedMhs.getNama().equalsIgnoreCase(txtNama.getText()) ||
                selectedMhs.getNilai() != Float.parseFloat(txtNilai.getText());
    }

    private void bersihkan() {
        txtNilai.clear();
        txtNama.clear();
        txtNim.clear();
        table.getSelectionModel().select(null);
    }

    private void addMahasiswa(Mahasiswa mahasiswa) {
        //validasi input!
        mahasiswaObservableList.add(mahasiswa);
    }

    public void onBtnHapusClick(ActionEvent actionEvent) {
        if (deleteMahasiswa(table.getSelectionModel().getSelectedItem())) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Data Mahasiswa dihapus");
            alert.show();
            bersihkan();
        }
    }

    private boolean deleteMahasiswa(Mahasiswa selectedItem) {
        return mahasiswaObservableList.remove(selectedItem);
    }

    public void onBtnSaveFileClick(ActionEvent actionEvent) {

    }

    public void onBtnCloseClick(ActionEvent actionEvent) {

    }

    public void onOpenBtnClick(ActionEvent actionEvent) {

    }

    public void onMenuAboutClicked(ActionEvent actionEvent) {
        HelloApplication.openViewWithModal("hello-view", false);
    }
}
