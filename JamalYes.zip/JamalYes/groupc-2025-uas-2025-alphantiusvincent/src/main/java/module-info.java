module com.ukdw.prplbo.jackpot {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.ukdw.prplbo.jackpot to javafx.fxml;
    exports com.ukdw.prplbo.jackpot;
}