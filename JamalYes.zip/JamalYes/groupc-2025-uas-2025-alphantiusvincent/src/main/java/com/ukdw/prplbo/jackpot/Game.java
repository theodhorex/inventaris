package com.ukdw.prplbo.jackpot;

import java.util.Random;

public class Game {
    private char letter1;
    private char letter2;
    private char letter3;
    private Random random;

    public Game() {
        random = new Random();
    }

    // Getters for letters
    public char getLetter1() {
        return letter1;
    }

    public char getLetter2() {
        return letter2;
    }

    public char getLetter3() {
        return letter3;
    }


    public void spin() {
        letter1 = (char) ('A' + random.nextInt(26));
        letter2 = (char) ('A' + random.nextInt(26));
        letter3 = (char) ('A' + random.nextInt(26));
    }


    public String evaluateResult() {
        if (letter1 == letter2 && letter2 == letter3) {
            return "Selamat anda menang mendapat Lucky Jackpot!";
        } else if (letter1 == letter2 || letter1 == letter3 || letter2 == letter3) {
            return "Selamat anda mendapat 2 huruf sama";
        } else {
            return "Maaf anda belum beruntung";
        }
    }
}