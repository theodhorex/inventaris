package com.ukdw.prplbo.jackpot;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.util.Duration;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class JackpotController {
    @FXML
    private Label label1;
    @FXML
    private Label label2;
    @FXML
    private Label label3;
    @FXML
    private Button spinButton;
    @FXML
    private Label resultLabel;

    private User currentUser;
    private Game game;
    private DatabaseManager dbManager;

    // A random object to quickly show random letters during animation
    private Random animationRandom;

    public void initialize() {
        game = new Game();
        dbManager = DatabaseManager.getInstance();
        animationRandom = new Random();
    }

    public void setUser(User user) {
        this.currentUser = user;
    }

    @FXML
    public void handleSpin() {
        //=======================================================
        //BAGIAN INI ADALAH JIKA ANDA MENGINGINKAN BONUS ANIMASI, KODE INI DAPAT
        //MENJADI INSPIRASI.  NAMUN JIKA TIDAK BISA, LEBIH BAIK GUNAKAN RANDOM BIASA
        //jika anda ingin menggunakan animasi huruf bergerak random bisa gunakan Timeline
        spinButton.setDisable(true);
        Timeline animation = new Timeline();
        animation.getKeyFrames().add(new KeyFrame(Duration.millis(100), e -> {
            label1.setText(String.valueOf((char) ('A' + animationRandom.nextInt(26))));
            label2.setText(String.valueOf((char) ('A' + animationRandom.nextInt(26))));
            label3.setText(String.valueOf((char) ('A' + animationRandom.nextInt(26))));
        }));
        //Timeline animation = new Timeline();
        animation.setCycleCount(10);
        animation.setOnFinished(event -> {
            game.spin();
            label1.setText(String.valueOf(game.getLetter1()));
            label2.setText(String.valueOf(game.getLetter2()));
            label3.setText(String.valueOf(game.getLetter3()));

            //animation.getKeyFrames().add(new KeyFrame(Duration.millis(100), e -> {
            //masukan disini 3 label yang menampilkan random huruf
            //}));
            String result = game.evaluateResult();
            resultLabel.setText(result);

            if (currentUser != null) {
                currentUser.increaseAttempts();
                currentUser.setStatus(result);
                dbManager.saveUser(currentUser);
            }

            spinButton.setDisable(false);
        });
        animation.play();
    }
}