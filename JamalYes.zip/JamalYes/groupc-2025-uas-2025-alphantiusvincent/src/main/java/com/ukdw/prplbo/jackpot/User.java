package com.ukdw.prplbo.jackpot;

public class User {
    private String username;
    private String password;
    private int attempts;
    private String status;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.attempts = 0;
        this.status = "";
    }


    public String getUsername() {
        return username;
    }
    public String getPassword() {
        return password;
    }
    public int getAttempts() {
        return attempts;
    }
    public String getStatus() {
        return status;
    }



    public void setUsername(String username) {
        this.username = username;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setAttempts(int attempts) {
        this.attempts = attempts;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public void increaseAttempts() {
        this.attempts++;
    }
}