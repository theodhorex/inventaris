package com.ukdw.prplbo.jackpot;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;

import java.io.IOException;

public class LoginController {
    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Label loginStatus;

    @FXML
    private void handleLogin(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.equals(password) && !username.isEmpty()) {
            User user = new User(username, password);
            try {

                FXMLLoader fxmlLoader = new FXMLLoader(JackpotApplication.class.getResource("jackpot.fxml"));
                Scene scene = new Scene(fxmlLoader.load());


                JackpotController jackpotController = fxmlLoader.getController();
                jackpotController.setUser(user);

                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.setTitle("Jackpot Game");
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
                loginStatus.setText("Error loading jackpot game.");
            }
        } else {
            loginStatus.setText("Username and password must be the same and not empty!");
        }
    }
}