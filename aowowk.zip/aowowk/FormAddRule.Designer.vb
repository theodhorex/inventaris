<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormAddRule
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PanelTop = New System.Windows.Forms.Panel()
        Me.LblTitle1 = New System.Windows.Forms.Label()
        Me.LblTitle2 = New System.Windows.Forms.Label()

        Me.LblWinner = New System.Windows.Forms.Label()
        Me.CmbWinner = New System.Windows.Forms.ComboBox()
        Me.TxtNamaWinner = New System.Windows.Forms.TextBox()
        Me.BtnBrowseWinner = New System.Windows.Forms.Button()
        Me.PbWinner = New System.Windows.Forms.PictureBox()

        Me.LblArrow = New System.Windows.Forms.Label()

        Me.LblLoser = New System.Windows.Forms.Label()
        Me.CmbLoser = New System.Windows.Forms.ComboBox()
        Me.TxtNamaLoser = New System.Windows.Forms.TextBox()
        Me.BtnBrowseLoser = New System.Windows.Forms.Button()
        Me.PbLoser = New System.Windows.Forms.PictureBox()

        Me.PanelBottom = New System.Windows.Forms.Panel()
        Me.BtnBatal = New System.Windows.Forms.Button()
        Me.BtnSimpan = New System.Windows.Forms.Button()

        Me.PanelTop.SuspendLayout()
        Me.PanelBottom.SuspendLayout()
        CType(Me.PbWinner, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbLoser, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()

        '--- PanelTop ---
        Me.PanelTop.BackColor = System.Drawing.Color.White
        Me.PanelTop.Controls.Add(Me.LblTitle1)
        Me.PanelTop.Controls.Add(Me.LblTitle2)
        Me.PanelTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelTop.Height = 75

        Me.LblTitle1.Text = "Tambah Rule"
        Me.LblTitle1.Font = New System.Drawing.Font("Segoe UI", 16, System.Drawing.FontStyle.Bold)
        Me.LblTitle1.AutoSize = True
        Me.LblTitle1.Location = New System.Drawing.Point(70, 8)

        Me.LblTitle2.Text = "Rock Paper Scissors"
        Me.LblTitle2.Font = New System.Drawing.Font("Segoe UI", 10)
        Me.LblTitle2.AutoSize = True
        Me.LblTitle2.Location = New System.Drawing.Point(70, 42)

        '--- WINNER section ---
        Me.LblWinner.Text = "Item yang lebih kuat:"
        Me.LblWinner.Font = New System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Bold)
        Me.LblWinner.Location = New System.Drawing.Point(15, 85)
        Me.LblWinner.AutoSize = True

        Me.CmbWinner.Location = New System.Drawing.Point(15, 108)
        Me.CmbWinner.Size = New System.Drawing.Size(200, 24)
        Me.CmbWinner.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList

        Me.TxtNamaWinner.Location = New System.Drawing.Point(15, 140)
        Me.TxtNamaWinner.Size = New System.Drawing.Size(200, 24)
        Me.TxtNamaWinner.PlaceholderText = "Nama item baru..."
        Me.TxtNamaWinner.Visible = False

        Me.BtnBrowseWinner.Text = "Browse Gambar"
        Me.BtnBrowseWinner.Location = New System.Drawing.Point(15, 170)
        Me.BtnBrowseWinner.Size = New System.Drawing.Size(120, 28)
        Me.BtnBrowseWinner.Visible = False
        Me.BtnBrowseWinner.FlatStyle = System.Windows.Forms.FlatStyle.Flat

        Me.PbWinner.Location = New System.Drawing.Point(240, 100)
        Me.PbWinner.Size = New System.Drawing.Size(100, 100)
        Me.PbWinner.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PbWinner.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PbWinner.BackColor = System.Drawing.Color.White

        '--- Arrow ---
        Me.LblArrow.Text = "▼"
        Me.LblArrow.Font = New System.Drawing.Font("Segoe UI", 24, System.Drawing.FontStyle.Bold)
        Me.LblArrow.Location = New System.Drawing.Point(150, 210)
        Me.LblArrow.AutoSize = True

        '--- LOSER section ---
        Me.LblLoser.Text = "Item yang lebih lemah:"
        Me.LblLoser.Font = New System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Bold)
        Me.LblLoser.Location = New System.Drawing.Point(15, 260)
        Me.LblLoser.AutoSize = True

        Me.CmbLoser.Location = New System.Drawing.Point(15, 283)
        Me.CmbLoser.Size = New System.Drawing.Size(200, 24)
        Me.CmbLoser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList

        Me.TxtNamaLoser.Location = New System.Drawing.Point(15, 315)
        Me.TxtNamaLoser.Size = New System.Drawing.Size(200, 24)
        Me.TxtNamaLoser.PlaceholderText = "Nama item baru..."
        Me.TxtNamaLoser.Visible = False

        Me.BtnBrowseLoser.Text = "Browse Gambar"
        Me.BtnBrowseLoser.Location = New System.Drawing.Point(15, 345)
        Me.BtnBrowseLoser.Size = New System.Drawing.Size(120, 28)
        Me.BtnBrowseLoser.Visible = False
        Me.BtnBrowseLoser.FlatStyle = System.Windows.Forms.FlatStyle.Flat

        Me.PbLoser.Location = New System.Drawing.Point(240, 273)
        Me.PbLoser.Size = New System.Drawing.Size(100, 100)
        Me.PbLoser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PbLoser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PbLoser.BackColor = System.Drawing.Color.White

        '--- PanelBottom ---
        Me.PanelBottom.BackColor = System.Drawing.Color.White
        Me.PanelBottom.Controls.Add(Me.BtnBatal)
        Me.PanelBottom.Controls.Add(Me.BtnSimpan)
        Me.PanelBottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelBottom.Height = 55

        Me.BtnBatal.Text = "Batal"
        Me.BtnBatal.Size = New System.Drawing.Size(90, 36)
        Me.BtnBatal.Location = New System.Drawing.Point(15, 10)
        Me.BtnBatal.BackColor = System.Drawing.Color.IndianRed
        Me.BtnBatal.ForeColor = System.Drawing.Color.White
        Me.BtnBatal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnBatal.Font = New System.Drawing.Font("Segoe UI", 10, System.Drawing.FontStyle.Bold)

        Me.BtnSimpan.Text = "Simpan"
        Me.BtnSimpan.Size = New System.Drawing.Size(90, 36)
        Me.BtnSimpan.Location = New System.Drawing.Point(250, 10)
        Me.BtnSimpan.BackColor = System.Drawing.Color.SeaGreen
        Me.BtnSimpan.ForeColor = System.Drawing.Color.White
        Me.BtnSimpan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSimpan.Font = New System.Drawing.Font("Segoe UI", 10, System.Drawing.FontStyle.Bold)

        '--- Form ---
        Me.ClientSize = New System.Drawing.Size(400, 500)
        Me.Controls.Add(Me.LblWinner)
        Me.Controls.Add(Me.CmbWinner)
        Me.Controls.Add(Me.TxtNamaWinner)
        Me.Controls.Add(Me.BtnBrowseWinner)
        Me.Controls.Add(Me.PbWinner)
        Me.Controls.Add(Me.LblArrow)
        Me.Controls.Add(Me.LblLoser)
        Me.Controls.Add(Me.CmbLoser)
        Me.Controls.Add(Me.TxtNamaLoser)
        Me.Controls.Add(Me.BtnBrowseLoser)
        Me.Controls.Add(Me.PbLoser)
        Me.Controls.Add(Me.PanelBottom)
        Me.Controls.Add(Me.PanelTop)
        Me.Name = "FormAddRule"
        Me.Text = "Tambah Rule"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent

        Me.PanelTop.ResumeLayout(False)
        Me.PanelTop.PerformLayout()
        Me.PanelBottom.ResumeLayout(False)
        CType(Me.PbWinner, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbLoser, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()
    End Sub

    Friend WithEvents PanelTop As System.Windows.Forms.Panel
    Friend WithEvents LblTitle1 As System.Windows.Forms.Label
    Friend WithEvents LblTitle2 As System.Windows.Forms.Label
    Friend WithEvents LblWinner As System.Windows.Forms.Label
    Friend WithEvents CmbWinner As System.Windows.Forms.ComboBox
    Friend WithEvents TxtNamaWinner As System.Windows.Forms.TextBox
    Friend WithEvents BtnBrowseWinner As System.Windows.Forms.Button
    Friend WithEvents PbWinner As System.Windows.Forms.PictureBox
    Friend WithEvents LblArrow As System.Windows.Forms.Label
    Friend WithEvents LblLoser As System.Windows.Forms.Label
    Friend WithEvents CmbLoser As System.Windows.Forms.ComboBox
    Friend WithEvents TxtNamaLoser As System.Windows.Forms.TextBox
    Friend WithEvents BtnBrowseLoser As System.Windows.Forms.Button
    Friend WithEvents PbLoser As System.Windows.Forms.PictureBox
    Friend WithEvents PanelBottom As System.Windows.Forms.Panel
    Friend WithEvents BtnBatal As System.Windows.Forms.Button
    Friend WithEvents BtnSimpan As System.Windows.Forms.Button

End Class
