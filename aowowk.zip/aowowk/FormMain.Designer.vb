<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PanelTop = New System.Windows.Forms.Panel()
        Me.BtnDaftarRule = New System.Windows.Forms.Button()
        Me.LabelTitle1 = New System.Windows.Forms.Label()
        Me.LabelTitle2 = New System.Windows.Forms.Label()
        Me.PanelLawan = New System.Windows.Forms.Panel()
        Me.LabelLawanJudul = New System.Windows.Forms.Label()
        Me.PictureBoxLawan = New System.Windows.Forms.PictureBox()
        Me.LabelLawanNama = New System.Windows.Forms.Label()
        Me.FlowLayoutPanelItems = New System.Windows.Forms.FlowLayoutPanel()
        Me.PanelTop.SuspendLayout()
        Me.PanelLawan.SuspendLayout()
        CType(Me.PictureBoxLawan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()

        '--- PanelTop (Toolbar) ---
        Me.PanelTop.BackColor = System.Drawing.Color.White
        Me.PanelTop.Controls.Add(Me.BtnDaftarRule)
        Me.PanelTop.Controls.Add(Me.LabelTitle1)
        Me.PanelTop.Controls.Add(Me.LabelTitle2)
        Me.PanelTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelTop.Height = 80
        Me.PanelTop.Name = "PanelTop"

        '--- BtnDaftarRule ---
        Me.BtnDaftarRule.Text = "📋"
        Me.BtnDaftarRule.Font = New System.Drawing.Font("Segoe UI", 14)
        Me.BtnDaftarRule.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnDaftarRule.FlatAppearance.BorderSize = 0
        Me.BtnDaftarRule.Size = New System.Drawing.Size(50, 50)
        Me.BtnDaftarRule.Location = New System.Drawing.Point(10, 15)
        Me.BtnDaftarRule.Name = "BtnDaftarRule"

        '--- LabelTitle1 ---
        Me.LabelTitle1.Text = "Dinamix"
        Me.LabelTitle1.Font = New System.Drawing.Font("Segoe UI", 18, System.Drawing.FontStyle.Bold)
        Me.LabelTitle1.AutoSize = True
        Me.LabelTitle1.Location = New System.Drawing.Point(70, 10)
        Me.LabelTitle1.Name = "LabelTitle1"

        '--- LabelTitle2 ---
        Me.LabelTitle2.Text = "Rock Paper Scissors"
        Me.LabelTitle2.Font = New System.Drawing.Font("Segoe UI", 11)
        Me.LabelTitle2.AutoSize = True
        Me.LabelTitle2.Location = New System.Drawing.Point(72, 45)
        Me.LabelTitle2.Name = "LabelTitle2"

        '--- PanelLawan ---
        Me.PanelLawan.BackColor = System.Drawing.Color.WhiteSmoke
        Me.PanelLawan.Controls.Add(Me.LabelLawanJudul)
        Me.PanelLawan.Controls.Add(Me.PictureBoxLawan)
        Me.PanelLawan.Controls.Add(Me.LabelLawanNama)
        Me.PanelLawan.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelLawan.Height = 160
        Me.PanelLawan.Name = "PanelLawan"
        Me.PanelLawan.Padding = New System.Windows.Forms.Padding(10)

        '--- LabelLawanJudul ---
        Me.LabelLawanJudul.Text = "Lawan:"
        Me.LabelLawanJudul.Font = New System.Drawing.Font("Segoe UI", 10, System.Drawing.FontStyle.Bold)
        Me.LabelLawanJudul.Location = New System.Drawing.Point(10, 10)
        Me.LabelLawanJudul.AutoSize = True
        Me.LabelLawanJudul.Name = "LabelLawanJudul"

        '--- PictureBoxLawan ---
        Me.PictureBoxLawan.Size = New System.Drawing.Size(100, 100)
        Me.PictureBoxLawan.Location = New System.Drawing.Point(80, 20)
        Me.PictureBoxLawan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBoxLawan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBoxLawan.BackColor = System.Drawing.Color.White
        Me.PictureBoxLawan.Name = "PictureBoxLawan"

        '--- LabelLawanNama ---
        Me.LabelLawanNama.Text = "?"
        Me.LabelLawanNama.Font = New System.Drawing.Font("Segoe UI", 10, System.Drawing.FontStyle.Bold)
        Me.LabelLawanNama.Location = New System.Drawing.Point(185, 60)
        Me.LabelLawanNama.AutoSize = True
        Me.LabelLawanNama.Name = "LabelLawanNama"

        '--- FlowLayoutPanelItems ---
        Me.FlowLayoutPanelItems.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanelItems.AutoScroll = True
        Me.FlowLayoutPanelItems.Padding = New System.Windows.Forms.Padding(10)
        Me.FlowLayoutPanelItems.WrapContents = True
        Me.FlowLayoutPanelItems.Name = "FlowLayoutPanelItems"
        Me.FlowLayoutPanelItems.BackColor = System.Drawing.Color.WhiteSmoke

        '--- FormMain ---
        Me.ClientSize = New System.Drawing.Size(400, 550)
        Me.Controls.Add(Me.FlowLayoutPanelItems)
        Me.Controls.Add(Me.PanelLawan)
        Me.Controls.Add(Me.PanelTop)
        Me.Name = "FormMain"
        Me.Text = "Dinamix Rock Paper Scissors"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen

        Me.PanelTop.ResumeLayout(False)
        Me.PanelTop.PerformLayout()
        Me.PanelLawan.ResumeLayout(False)
        Me.PanelLawan.PerformLayout()
        CType(Me.PictureBoxLawan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
    End Sub

    Friend WithEvents PanelTop As System.Windows.Forms.Panel
    Friend WithEvents BtnDaftarRule As System.Windows.Forms.Button
    Friend WithEvents LabelTitle1 As System.Windows.Forms.Label
    Friend WithEvents LabelTitle2 As System.Windows.Forms.Label
    Friend WithEvents PanelLawan As System.Windows.Forms.Panel
    Friend WithEvents LabelLawanJudul As System.Windows.Forms.Label
    Friend WithEvents PictureBoxLawan As System.Windows.Forms.PictureBox
    Friend WithEvents LabelLawanNama As System.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanelItems As System.Windows.Forms.FlowLayoutPanel

End Class
