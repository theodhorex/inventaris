Imports System.IO

Public Class FormMain

    ' Path file
    Private itemFile As String = Path.Combine(Application.StartupPath, "items.txt")
    Private ruleFile As String = Path.Combine(Application.StartupPath, "rules.txt")
    Private imagesFolder As String = Path.Combine(Application.StartupPath, "images")

    ' Struktur data item
    Private Class ItemData
        Public Property Id As Integer
        Public Property Nama As String
        Public Property ImageFile As String
    End Class

    ' Struktur data rule
    Private Class RuleData
        Public Property WinnerId As Integer
        Public Property LoserId As Integer
    End Class

    Private listItem As New List(Of ItemData)
    Private listRule As New List(Of RuleData)

    ' Timer untuk animasi random
    Private WithEvents tmrRandom As New Timer()
    Private animCounter As Integer = 0
    Private selectedItemId As Integer = -1
    Private rnd As New Random()

    ' Panel yang sedang dipilih
    Private selectedPanel As Panel = Nothing

#Region "LOAD & INIT"

    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tmrRandom.Interval = 150
        AddHandler tmrRandom.Tick, AddressOf TmrRandom_Tick

        LoadItems()
        LoadRules()
        RenderItemButtons()
    End Sub

    Private Sub LoadItems()
        listItem.Clear()
        If Not File.Exists(itemFile) Then Exit Sub

        For Each line In File.ReadAllLines(itemFile)
            Dim parts = line.Split(","c)
            If parts.Length >= 3 Then
                Dim item As New ItemData()
                item.Id = CInt(parts(0).Trim())
                item.Nama = parts(1).Trim()
                item.ImageFile = parts(2).Trim()
                listItem.Add(item)
            End If
        Next
    End Sub

    Private Sub LoadRules()
        listRule.Clear()
        If Not File.Exists(ruleFile) Then Exit Sub

        For Each line In File.ReadAllLines(ruleFile)
            If line.Trim().ToLower() = "else draw" Then Continue For
            Dim parts = line.Split(">"c)
            If parts.Length = 2 Then
                Dim r As New RuleData()
                r.WinnerId = CInt(parts(0).Trim())
                r.LoserId = CInt(parts(1).Trim())
                listRule.Add(r)
            End If
        Next
    End Sub

#End Region

#Region "RENDER ITEMS DINAMIS"

    Private Sub RenderItemButtons()
        ' Bersihkan panel item dulu
        FlowLayoutPanelItems.Controls.Clear()

        For Each item In listItem
            ' Panel per item
            Dim pnl As New Panel()
            pnl.Size = New Size(110, 130)
            pnl.BackColor = Color.White
            pnl.Cursor = Cursors.Hand
            pnl.Tag = item.Id
            pnl.Padding = New Padding(5)

            ' PictureBox gambar item
            Dim pb As New PictureBox()
            pb.Size = New Size(90, 90)
            pb.Location = New Point(10, 5)
            pb.SizeMode = PictureBoxSizeMode.Zoom
            pb.Tag = item.Id
            pb.Cursor = Cursors.Hand
            LoadImageSafe(pb, item.ImageFile)

            ' Label nama item
            Dim lbl As New Label()
            lbl.Text = item.Nama
            lbl.Location = New Point(0, 100)
            lbl.Size = New Size(110, 25)
            lbl.TextAlign = ContentAlignment.MiddleCenter
            lbl.Font = New Font("Segoe UI", 9, FontStyle.Bold)
            lbl.Tag = item.Id
            lbl.Cursor = Cursors.Hand

            ' Event click
            AddHandler pnl.Click, AddressOf Item_Click
            AddHandler pb.Click, AddressOf Item_Click
            AddHandler lbl.Click, AddressOf Item_Click

            pnl.Controls.Add(pb)
            pnl.Controls.Add(lbl)
            FlowLayoutPanelItems.Controls.Add(pnl)
        Next
    End Sub

    Private Sub LoadImageSafe(pb As PictureBox, imgName As String)
        Try
            Dim imgPath As String = Path.Combine(imagesFolder, imgName)
            If File.Exists(imgPath) Then
                Using fs As New FileStream(imgPath, FileMode.Open, FileAccess.Read, FileShare.Read)
                    Using temp = Image.FromStream(fs)
                        pb.Image = New Bitmap(temp)
                    End Using
                End Using
            End If
        Catch
            ' Abaikan error load gambar
        End Try
    End Sub

#End Region

#Region "GAME LOGIC"

    Private Sub Item_Click(sender As Object, e As EventArgs)
        If tmrRandom.Enabled Then Exit Sub ' Sedang animasi, abaikan klik

        Dim clickedId As Integer = CInt(DirectCast(sender, Control).Tag)
        selectedItemId = clickedId

        ' Highlight item yang dipilih
        HighlightSelected(clickedId)

        ' Reset tampilan lawan
        PictureBoxLawan.Image = Nothing
        LabelLawanNama.Text = "?"

        ' Mulai animasi random
        animCounter = 0
        tmrRandom.Start()
    End Sub

    Private Sub HighlightSelected(itemId As Integer)
        For Each ctrl As Control In FlowLayoutPanelItems.Controls
            If TypeOf ctrl Is Panel Then
                If CInt(ctrl.Tag) = itemId Then
                    ctrl.BackColor = Color.LightSkyBlue
                    selectedPanel = DirectCast(ctrl, Panel)
                Else
                    ctrl.BackColor = Color.White
                End If
            End If
        Next
    End Sub

    Private Sub TmrRandom_Tick(sender As Object, e As EventArgs)
        ' Animasi: tampilkan item acak selama ~3 detik (20 tick x 150ms = 3000ms)
        animCounter += 1

        Dim idxAcak As Integer = rnd.Next(0, listItem.Count)
        Dim itemAcak = listItem(idxAcak)

        ' Tampilkan di area lawan
        LoadImageSafe(PictureBoxLawan, itemAcak.ImageFile)
        LabelLawanNama.Text = itemAcak.Nama

        If animCounter >= 20 Then
            tmrRandom.Stop()
            TentukanHasil(itemAcak.Id)
        End If
    End Sub

    Private Sub TentukanHasil(lawanId As Integer)
        Dim pemainId = selectedItemId

        ' Cari rule
        Dim pemainMenang = listRule.Any(Function(r) r.WinnerId = pemainId AndAlso r.LoserId = lawanId)
        Dim pemainKalah = listRule.Any(Function(r) r.WinnerId = lawanId AndAlso r.LoserId = pemainId)

        Dim pesan As String
        Dim icon As MessageBoxIcon

        If pemainId = lawanId Then
            pesan = "Seri (Draw)!"
            icon = MessageBoxIcon.Information
        ElseIf pemainMenang Then
            pesan = "Kamu Menang!"
            icon = MessageBoxIcon.Information
        ElseIf pemainKalah Then
            pesan = "Kamu Kalah!"
            icon = MessageBoxIcon.Warning
        Else
            pesan = "Seri (Draw)!"
            icon = MessageBoxIcon.Information
        End If

        MessageBox.Show(pesan, "Hasil", MessageBoxButtons.OK, icon)
    End Sub

#End Region

#Region "TOOLBAR BUTTONS"

    ' Tombol buka Form Daftar Rule
    Private Sub BtnDaftarRule_Click(sender As Object, e As EventArgs) Handles BtnDaftarRule.Click
        Dim f As New FormDaftarRule()
        f.ShowDialog()
        ' Reload data setelah kembali (mungkin ada rule baru)
        LoadItems()
        LoadRules()
        RenderItemButtons()
    End Sub

#End Region

End Class
