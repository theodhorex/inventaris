Imports System.IO

Public Class FormAddRule

    Private itemFile As String = Path.Combine(Application.StartupPath, "items.txt")
    Private ruleFile As String = Path.Combine(Application.StartupPath, "rules.txt")
    Private imagesFolder As String = Path.Combine(Application.StartupPath, "images")

    Private Class ItemData
        Public Property Id As Integer
        Public Property Nama As String
        Public Property ImageFile As String
        Public Overrides Function ToString() As String
            Return Nama
        End Function
    End Class

    Private listItem As New List(Of ItemData)

    ' Path gambar item baru (jika browse)
    Private sourcePathWinner As String = ""
    Private sourcePathLoser As String = ""

    Private Sub FormAddRule_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadItems()
        PopulateComboBoxes()
    End Sub

    Private Sub LoadItems()
        listItem.Clear()
        If Not File.Exists(itemFile) Then Exit Sub
        For Each line In File.ReadAllLines(itemFile)
            Dim parts = line.Split(","c)
            If parts.Length >= 3 Then
                Dim item As New ItemData()
                item.Id = CInt(parts(0).Trim())
                item.Nama = parts(1).Trim()
                item.ImageFile = parts(2).Trim()
                listItem.Add(item)
            End If
        Next
    End Sub

    Private Sub PopulateComboBoxes()
        CmbWinner.Items.Clear()
        CmbLoser.Items.Clear()

        ' Tambah opsi "-- Tambah Baru --" di atas
        CmbWinner.Items.Add("-- Tambah Baru --")
        CmbLoser.Items.Add("-- Tambah Baru --")

        For Each item In listItem
            CmbWinner.Items.Add(item)
            CmbLoser.Items.Add(item)
        Next

        CmbWinner.SelectedIndex = 0
        CmbLoser.SelectedIndex = 0
    End Sub

#Region "COMBOBOX CHANGE"

    Private Sub CmbWinner_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbWinner.SelectedIndexChanged
        Dim isBaru = (CmbWinner.SelectedIndex = 0)
        TxtNamaWinner.Visible = isBaru
        BtnBrowseWinner.Visible = isBaru
        PbWinner.Image = Nothing
        sourcePathWinner = ""

        If Not isBaru AndAlso CmbWinner.SelectedItem IsNot Nothing Then
            Dim selected = DirectCast(CmbWinner.SelectedItem, ItemData)
            LoadPreview(PbWinner, selected.ImageFile)
        End If
    End Sub

    Private Sub CmbLoser_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbLoser.SelectedIndexChanged
        Dim isBaru = (CmbLoser.SelectedIndex = 0)
        TxtNamaLoser.Visible = isBaru
        BtnBrowseLoser.Visible = isBaru
        PbLoser.Image = Nothing
        sourcePathLoser = ""

        If Not isBaru AndAlso CmbLoser.SelectedItem IsNot Nothing Then
            Dim selected = DirectCast(CmbLoser.SelectedItem, ItemData)
            LoadPreview(PbLoser, selected.ImageFile)
        End If
    End Sub

#End Region

#Region "BROWSE GAMBAR"

    Private Sub BtnBrowseWinner_Click(sender As Object, e As EventArgs) Handles BtnBrowseWinner.Click
        sourcePathWinner = BrowseImage()
        If sourcePathWinner <> "" Then
            PbWinner.Image = Image.FromFile(sourcePathWinner)
        End If
    End Sub

    Private Sub BtnBrowseLoser_Click(sender As Object, e As EventArgs) Handles BtnBrowseLoser.Click
        sourcePathLoser = BrowseImage()
        If sourcePathLoser <> "" Then
            PbLoser.Image = Image.FromFile(sourcePathLoser)
        End If
    End Sub

    Private Function BrowseImage() As String
        Using dlg As New OpenFileDialog()
            dlg.Title = "Pilih Gambar"
            dlg.Filter = "Image Files|*.png;*.jpg;*.jpeg;*.bmp;*.gif"
            If dlg.ShowDialog() = DialogResult.OK Then
                Return dlg.FileName
            End If
        End Using
        Return ""
    End Function

    Private Sub LoadPreview(pb As PictureBox, imgName As String)
        Try
            Dim imgPath = Path.Combine(imagesFolder, imgName)
            If File.Exists(imgPath) Then
                Using fs As New FileStream(imgPath, FileMode.Open, FileAccess.Read, FileShare.Read)
                    Using temp = Image.FromStream(fs)
                        pb.Image = New Bitmap(temp)
                    End Using
                End Using
            End If
        Catch
        End Try
    End Sub

#End Region

#Region "SIMPAN"

    Private Sub BtnSimpan_Click(sender As Object, e As EventArgs) Handles BtnSimpan.Click
        ' --- Validasi & resolve Winner ---
        Dim winnerId As Integer
        Dim winnerNama As String
        Dim winnerImg As String

        If CmbWinner.SelectedIndex = 0 Then
            ' Item baru
            winnerNama = TxtNamaWinner.Text.Trim()
            If winnerNama = "" Then
                MessageBox.Show("Nama item Winner tidak boleh kosong!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                TxtNamaWinner.Focus()
                Return
            End If
            ' Cek duplikat nama
            If listItem.Any(Function(x) x.Nama.ToLower() = winnerNama.ToLower()) Then
                MessageBox.Show("Nama item Winner sudah ada (duplikat)!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If
            If sourcePathWinner = "" Then
                MessageBox.Show("Pilih gambar untuk item Winner!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If
            winnerImg = CopyImageToProject(sourcePathWinner)
            winnerId = GetNextId()
            TambahItemBaru(winnerId, winnerNama, winnerImg)
            LoadItems() ' reload biar list terupdate
        Else
            Dim sel = DirectCast(CmbWinner.SelectedItem, ItemData)
            winnerId = sel.Id
        End If

        ' --- Validasi & resolve Loser ---
        Dim loserId As Integer
        Dim loserNama As String
        Dim loserImg As String

        ' Reload supaya dapat item baru yang mungkin baru ditambah
        LoadItems()

        If CmbLoser.SelectedIndex = 0 Then
            loserNama = TxtNamaLoser.Text.Trim()
            If loserNama = "" Then
                MessageBox.Show("Nama item Loser tidak boleh kosong!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                TxtNamaLoser.Focus()
                Return
            End If
            If listItem.Any(Function(x) x.Nama.ToLower() = loserNama.ToLower()) Then
                MessageBox.Show("Nama item Loser sudah ada (duplikat)!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If
            If sourcePathLoser = "" Then
                MessageBox.Show("Pilih gambar untuk item Loser!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If
            loserImg = CopyImageToProject(sourcePathLoser)
            loserId = GetNextId()
            TambahItemBaru(loserId, loserNama, loserImg)
        Else
            Dim sel = DirectCast(CmbLoser.SelectedItem, ItemData)
            loserId = sel.Id
        End If

        ' Cek tidak sama
        If winnerId = loserId Then
            MessageBox.Show("Winner dan Loser tidak boleh item yang sama!", "Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Simpan rule ke file
        TambahRule(winnerId, loserId)

        MessageBox.Show("Rule berhasil disimpan!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Function GetNextId() As Integer
        If listItem.Count = 0 Then Return 1
        Return listItem.Max(Function(x) x.Id) + 1
    End Function

    Private Sub TambahItemBaru(id As Integer, nama As String, imgFile As String)
        File.AppendAllText(itemFile, Environment.NewLine & $"{id},{nama},{imgFile}")
    End Sub

    Private Sub TambahRule(winnerId As Integer, loserId As Integer)
        ' Baca semua baris, hapus "else draw", tambah rule baru, tambah lagi "else draw"
        Dim lines As New List(Of String)
        If File.Exists(ruleFile) Then
            lines = File.ReadAllLines(ruleFile).ToList()
            lines = lines.Where(Function(l) l.Trim().ToLower() <> "else draw").ToList()
        End If
        lines.Add($"{winnerId}>{loserId}")
        lines.Add("else draw")
        File.WriteAllLines(ruleFile, lines)
    End Sub

    Private Function CopyImageToProject(srcPath As String) As String
        If Not Directory.Exists(imagesFolder) Then
            Directory.CreateDirectory(imagesFolder)
        End If

        Dim fileName As String = Path.GetFileName(srcPath)
        Dim destPath As String = Path.Combine(imagesFolder, fileName)

        ' Kalau nama sama, kasih suffix
        If File.Exists(destPath) Then
            Dim baseName = Path.GetFileNameWithoutExtension(fileName)
            Dim ext = Path.GetExtension(fileName)
            Dim i = 1
            Do While File.Exists(destPath)
                fileName = baseName & "_" & i & ext
                destPath = Path.Combine(imagesFolder, fileName)
                i += 1
            Loop
        End If

        File.Copy(srcPath, destPath)
        Return fileName
    End Function

#End Region

    Private Sub BtnBatal_Click(sender As Object, e As EventArgs) Handles BtnBatal.Click
        Me.Close()
    End Sub

End Class
