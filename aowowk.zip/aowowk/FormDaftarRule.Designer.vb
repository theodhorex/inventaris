<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormDaftarRule
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PanelTop = New System.Windows.Forms.Panel()
        Me.LabelTitle1 = New System.Windows.Forms.Label()
        Me.LabelTitle2 = New System.Windows.Forms.Label()
        Me.LvwRule = New System.Windows.Forms.ListView()
        Me.PanelBottom = New System.Windows.Forms.Panel()
        Me.BtnKembali = New System.Windows.Forms.Button()
        Me.BtnTambah = New System.Windows.Forms.Button()
        Me.PanelTop.SuspendLayout()
        Me.PanelBottom.SuspendLayout()
        Me.SuspendLayout()

        '--- PanelTop ---
        Me.PanelTop.BackColor = System.Drawing.Color.White
        Me.PanelTop.Controls.Add(Me.LabelTitle1)
        Me.PanelTop.Controls.Add(Me.LabelTitle2)
        Me.PanelTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelTop.Height = 80

        Me.LabelTitle1.Text = "Daftar Rule"
        Me.LabelTitle1.Font = New System.Drawing.Font("Segoe UI", 16, System.Drawing.FontStyle.Bold)
        Me.LabelTitle1.AutoSize = True
        Me.LabelTitle1.Location = New System.Drawing.Point(80, 10)

        Me.LabelTitle2.Text = "Rock Paper Scissors"
        Me.LabelTitle2.Font = New System.Drawing.Font("Segoe UI", 10)
        Me.LabelTitle2.AutoSize = True
        Me.LabelTitle2.Location = New System.Drawing.Point(80, 45)

        '--- ListView ---
        Me.LvwRule.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LvwRule.Name = "LvwRule"

        '--- PanelBottom ---
        Me.PanelBottom.BackColor = System.Drawing.Color.White
        Me.PanelBottom.Controls.Add(Me.BtnKembali)
        Me.PanelBottom.Controls.Add(Me.BtnTambah)
        Me.PanelBottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelBottom.Height = 55

        '--- BtnKembali ---
        Me.BtnKembali.Text = "←"
        Me.BtnKembali.Font = New System.Drawing.Font("Segoe UI", 14)
        Me.BtnKembali.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnKembali.Size = New System.Drawing.Size(50, 40)
        Me.BtnKembali.Location = New System.Drawing.Point(10, 8)
        Me.BtnKembali.BackColor = System.Drawing.Color.LightGray

        '--- BtnTambah ---
        Me.BtnTambah.Text = "+"
        Me.BtnTambah.Font = New System.Drawing.Font("Segoe UI", 16, System.Drawing.FontStyle.Bold)
        Me.BtnTambah.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTambah.Size = New System.Drawing.Size(50, 40)
        Me.BtnTambah.Location = New System.Drawing.Point(340, 8)
        Me.BtnTambah.BackColor = System.Drawing.Color.LimeGreen
        Me.BtnTambah.ForeColor = System.Drawing.Color.White

        '--- Form ---
        Me.ClientSize = New System.Drawing.Size(400, 500)
        Me.Controls.Add(Me.LvwRule)
        Me.Controls.Add(Me.PanelBottom)
        Me.Controls.Add(Me.PanelTop)
        Me.Name = "FormDaftarRule"
        Me.Text = "Daftar Rule - ListView"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent

        Me.PanelTop.ResumeLayout(False)
        Me.PanelTop.PerformLayout()
        Me.PanelBottom.ResumeLayout(False)
        Me.ResumeLayout(False)
    End Sub

    Friend WithEvents PanelTop As System.Windows.Forms.Panel
    Friend WithEvents LabelTitle1 As System.Windows.Forms.Label
    Friend WithEvents LabelTitle2 As System.Windows.Forms.Label
    Friend WithEvents LvwRule As System.Windows.Forms.ListView
    Friend WithEvents PanelBottom As System.Windows.Forms.Panel
    Friend WithEvents BtnKembali As System.Windows.Forms.Button
    Friend WithEvents BtnTambah As System.Windows.Forms.Button

End Class
