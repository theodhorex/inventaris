module com.example.minggu10 {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires java.sql;
    requires java.desktop;

    opens com.example.minggu10 to javafx.fxml;
    exports com.example.minggu10;
    exports com.example.minggu10.util;
    opens com.example.minggu10.util to javafx.fxml;
    exports com.example.minggu10.view;
    opens com.example.minggu10.view to javafx.fxml;
    exports com.example.minggu10.data;
    opens com.example.minggu10.data to javafx.fxml;
}