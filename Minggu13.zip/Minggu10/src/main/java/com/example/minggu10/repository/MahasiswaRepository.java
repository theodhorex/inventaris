package com.example.minggu10.repository;

import com.example.minggu10.data.Mahasiswa;
import com.example.minggu10.util.DBManager;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MahasiswaRepository implements Dao<Mahasiswa, String> {


    private Connection connection;
    public MahasiswaRepository(Connection connection) {
        this.connection = connection;
        buatTableJikaBelumAda();
    }

    @Override
    public Mahasiswa findById(String id) {
        return null;
    }

    private void buatTableJikaBelumAda() {
        String sql = "CREATE TABLE IF NOT EXISTS mahasiswa (" +
                "nim TEXT PRIMARY KEY," +
                "nama TEXT NOT NULL," +
                "nilai REAL NOT NULL," +
                "foto BLOB)";
        try {
            Statement stmt = connection.createStatement();
            stmt.execute(sql);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Mahasiswa> findAll() {
        ArrayList<Mahasiswa> list = new ArrayList<>();
        String sql = "SELECT * FROM mahasiswa";
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                list.add(new Mahasiswa(
                        rs.getString("nim"),
                        rs.getString("nama"),
                        rs.getFloat("nilai"),
                        rs.getBytes("foto")
                ));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return list;
    }

    @Override
    public boolean save(Mahasiswa mahasiswa) {
        String sql = "INSERT INTO mahasiswa (nim, nama, nilai, foto) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, mahasiswa.getNim());
            pstmt.setString(2, mahasiswa.getNama());
            pstmt.setDouble(3, mahasiswa.getNilai());
            pstmt.setBytes(4, mahasiswa.getFoto());
            pstmt.executeUpdate();
            System.out.println("Mahasiswa berhasil ditambahkan.");
            return true;
        } catch (SQLException e) {
            System.err.println("Gagal menambahkan mahasiswa: " +
                    e.getMessage());
            return false;
        }
    }

    @Override
    public boolean update(Mahasiswa mahasiswa) {
        String sql = "UPDATE mahasiswa SET nama = ?, nilai = ? , foto = ? WHERE nim = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, mahasiswa.getNama());
            pstmt.setDouble(2, mahasiswa.getNilai());
            pstmt.setBytes(3, mahasiswa.getFoto());
            pstmt.setString(4, mahasiswa.getNim());
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Data mahasiswa berhasil diperbarui.");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Gagal memperbarui data mahasiswa: " +
                    e.getMessage());
        }
        return false;
    }

    @Override
    public boolean delete(Mahasiswa mahasiswa) {
        String sql = "DELETE FROM mahasiswa WHERE nim = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, mahasiswa.getNim());
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Mahasiswa dengan NIM " + mahasiswa.getNim() + " telah dihapus.");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Gagal menghapus mahasiswa: " +
                    e.getMessage());
        }
        return false;

    }

}
