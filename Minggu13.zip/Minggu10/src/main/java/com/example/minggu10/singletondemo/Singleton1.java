package com.example.minggu10.singletondemo;

public class Singleton1 {

    private static volatile Singleton1 instance;
    private int count = 0;
    private Singleton1() {
    }

    public static synchronized Singleton1 getInstance() {
        if (instance == null) {
            synchronized (Singleton1.class) {
                if (instance == null) {
                    instance = new Singleton1();
                }
            }
        }
        return instance;
    }

    public int getCount() {
        return count;
    }

    public void increase() {
        this.count++;
    }
}
