package com.example.minggu10.managers;

import com.example.minggu10.data.Mahasiswa;
import com.example.minggu10.repository.Dao;
import com.example.minggu10.repository.MahasiswaRepository;
import com.example.minggu10.util.DBManager;

import java.util.ArrayList;

public class MahasiswaManager {

    Dao<Mahasiswa, String> mahasiswaRepository;

    public MahasiswaManager() {
        mahasiswaRepository = new MahasiswaRepository(DBManager.getConnection());
    }

    public ArrayList<Mahasiswa> getAllMahasiswa() {
        return (ArrayList<Mahasiswa>) mahasiswaRepository.findAll();
    }

    public boolean addMahasiswa(Mahasiswa mahasiswa) {
        return mahasiswaRepository.save(mahasiswa);
    }

    public boolean updateMahasiswa(Mahasiswa mahasiswa) {
        return mahasiswaRepository.update(mahasiswa);
    }

    public boolean deleteMahasiswa(Mahasiswa mahasiswa) {
        return mahasiswaRepository.delete(mahasiswa);
    }
}
