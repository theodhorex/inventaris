package com.example.minggu10.view;

import com.example.minggu10.HelloApplication;
import com.example.minggu10.util.SessionManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

public class LoginController {

    @FXML
    private Button btnLogin;

    @FXML
    private Hyperlink lblForgot;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private TextField txtUsername;

    @FXML
    void btnLoginClick(ActionEvent event) {
        String username = txtUsername.getText();
        String password = txtPassword.getText();
        if (username.equals("admin") && password.equals("admin")) {
            HelloApplication.openViewWithModal("mahasiswa-view", false);
            SessionManager.getInstance().login();
        }
    }

    @FXML
    void onKeyPressEvent(KeyEvent event) {

    }

}
