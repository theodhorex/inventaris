package com.example.minggu10.singletondemo;

public class DemoSingleton {
    public static void main(String[] args) {
        Kelas1 kelas1 = new Kelas1();
        System.out.println(Singleton1.getInstance().getCount());
        Kelas2 kelas2 = new Kelas2();
        System.out.println(Singleton1.getInstance().getCount());
        Singleton1.getInstance().increase();
        System.out.println(Singleton1.getInstance().getCount());
    }
}

class Kelas1 {
    public Kelas1() {
        Singleton1 singleton1;
        Singleton1.getInstance().increase();
    }
}

class Kelas2 {
    public Kelas2() {
        Singleton1.getInstance().increase();
    }
}
