package com.example.minggu10.repository;

import java.util.List;

public interface Dao <ObjectType, IdType>{
    ObjectType findById(IdType id);

    List<ObjectType> findAll();

    boolean save(ObjectType object);
    boolean update(ObjectType object);
    boolean delete(ObjectType object);
}
