package org.example.coba;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.String;

public class Petinju {
    private String nama;
    private int stamina;
    private int kekuatan;

    public Petinju(String nama, int kekuatan) {
        String total = "";
        for(String numString : nama.split("[^0-9]+")) {
            if(!numString.isEmpty()) {
                total += numString;
            }
        }
        String name1 = nama.replace(total, "");
        this.stamina = Integer.parseInt(total);
        this.nama = name1;
        this.kekuatan = kekuatan;
    }

    public void tinju(Samsak samsak) {
        if (stamina > 0) {
            int daya = samsak.getDayaTahan();
            samsak.setDayaTahan(daya - kekuatan);

            stamina = stamina-kekuatan;
            System.out.println("Daya Tahan samsak berkurang : " + kekuatan);
            System.out.println("Stamina petinju " + nama + " tersisa : " + stamina);
            System.out.println("Daya Tahan samsak tersisa : " + samsak.getDayaTahan());

            if (samsak.getDayaTahan() <= 0) {
                System.out.println("samsak hancur!");
                samsak.setRusak(true);
            } else if (samsak.getTingkatKekerasan() > kekuatan) {
                System.out.println("samsak terlalu keras bagi " + nama + " si petinju");
                samsak.setRusak(true);
            }
        } else if (stamina <= 0) {
            System.out.println("Stamina petinju " + nama + " sudah habis!");
            samsak.setRusak(true);
            if (samsak.getTingkatKekerasan() > kekuatan) {
                System.out.println("samsak terlalu keras bagi " + nama + " si petinju");
                samsak.setRusak(true);
            }
        }

    }

    public String getNama() {
        return nama;
    }

    public int getStamina() {
        return stamina;
    }

    public int getKekuatan() {
        return kekuatan;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setStamina(int stamina) {
        this.stamina = stamina;
    }

    public void setKekuatan(int kekuatan) {
        this.kekuatan = kekuatan;
    }
}
