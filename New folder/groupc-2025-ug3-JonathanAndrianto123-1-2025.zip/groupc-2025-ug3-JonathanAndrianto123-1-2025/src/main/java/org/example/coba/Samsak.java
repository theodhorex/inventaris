package org.example.coba;

public class Samsak {
    private int dayaTahan;
    private int tingkatKekerasan;
    private boolean rusak = false;

    public Samsak(int dayaTahan, int tingkatKekerasan) {
        this.dayaTahan = dayaTahan;
        this.tingkatKekerasan = tingkatKekerasan;
        if (dayaTahan <= 0) {
            this.rusak = true;
        }
    }

    public int getDayaTahan() {
        return dayaTahan;
    }

    public int getTingkatKekerasan() {
        return tingkatKekerasan;
    }

    public boolean isRusak() {
        return rusak;
    }

    public void setRusak(boolean rusak) {
        this.rusak = rusak;
    }

    public void setDayaTahan(int dayaTahan) {
        this.dayaTahan = dayaTahan;
    }

    public void setTingkatKekerasan(int tingkatKekerasan) {
        this.tingkatKekerasan = tingkatKekerasan;
    }
}
